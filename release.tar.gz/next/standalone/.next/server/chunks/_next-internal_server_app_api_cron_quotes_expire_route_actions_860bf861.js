module.exports=[194222,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_cron_quotes_expire_route_actions_860bf861.js.map