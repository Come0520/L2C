module.exports=[309588,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_health_route_actions_da3433c4.js.map