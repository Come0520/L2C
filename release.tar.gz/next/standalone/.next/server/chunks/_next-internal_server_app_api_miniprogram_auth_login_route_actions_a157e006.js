module.exports=[272791,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_miniprogram_auth_login_route_actions_a157e006.js.map