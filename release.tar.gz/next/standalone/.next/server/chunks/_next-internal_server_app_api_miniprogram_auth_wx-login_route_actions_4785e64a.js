module.exports=[627761,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_miniprogram_auth_wx-login_route_actions_4785e64a.js.map