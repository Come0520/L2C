module.exports=[715761,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_miniprogram_calculate_route_actions_9ba02646.js.map