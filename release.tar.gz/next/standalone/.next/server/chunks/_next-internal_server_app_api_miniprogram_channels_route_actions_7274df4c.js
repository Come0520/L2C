module.exports=[844371,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_miniprogram_channels_route_actions_7274df4c.js.map