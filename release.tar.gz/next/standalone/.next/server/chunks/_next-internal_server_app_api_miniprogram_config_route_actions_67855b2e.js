module.exports=[390157,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_miniprogram_config_route_actions_67855b2e.js.map