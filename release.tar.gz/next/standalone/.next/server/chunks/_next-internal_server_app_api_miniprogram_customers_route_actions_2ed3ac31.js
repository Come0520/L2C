module.exports=[618565,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_miniprogram_customers_route_actions_2ed3ac31.js.map