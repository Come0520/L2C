module.exports=[650358,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_miniprogram_dashboard_route_actions_38dc1676.js.map