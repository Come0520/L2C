module.exports=[597623,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_miniprogram_invite_accept_route_actions_bb909d12.js.map