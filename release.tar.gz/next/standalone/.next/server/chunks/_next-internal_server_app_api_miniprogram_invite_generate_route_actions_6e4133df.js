module.exports=[969666,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_miniprogram_invite_generate_route_actions_6e4133df.js.map