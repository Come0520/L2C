module.exports=[126254,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_miniprogram_invite_list_route_actions_be9392b5.js.map