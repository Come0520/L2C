module.exports=[139553,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_miniprogram_invite_qrcode_route_actions_6ab5d545.js.map