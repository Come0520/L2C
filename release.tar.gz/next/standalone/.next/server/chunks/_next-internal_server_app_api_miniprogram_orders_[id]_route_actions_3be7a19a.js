module.exports=[15599,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_miniprogram_orders_%5Bid%5D_route_actions_3be7a19a.js.map