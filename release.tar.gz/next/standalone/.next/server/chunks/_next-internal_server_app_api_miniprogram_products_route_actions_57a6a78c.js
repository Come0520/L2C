module.exports=[2787,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_miniprogram_products_route_actions_57a6a78c.js.map