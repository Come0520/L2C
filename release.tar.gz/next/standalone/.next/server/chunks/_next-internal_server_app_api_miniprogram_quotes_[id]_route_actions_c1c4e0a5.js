module.exports=[883897,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_miniprogram_quotes_%5Bid%5D_route_actions_c1c4e0a5.js.map