module.exports=[541313,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_miniprogram_quotes_route_actions_d66ed282.js.map