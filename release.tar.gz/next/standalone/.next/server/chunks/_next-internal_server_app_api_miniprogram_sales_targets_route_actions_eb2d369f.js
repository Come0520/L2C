module.exports=[18025,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_miniprogram_sales_targets_route_actions_eb2d369f.js.map