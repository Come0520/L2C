module.exports=[404539,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_miniprogram_service_tickets_route_actions_6060e6da.js.map