module.exports=[802514,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_miniprogram_tenant_apply_route_actions_78597468.js.map