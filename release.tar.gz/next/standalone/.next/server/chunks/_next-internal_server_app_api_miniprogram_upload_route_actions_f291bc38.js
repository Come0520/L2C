module.exports=[831632,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_miniprogram_upload_route_actions_f291bc38.js.map