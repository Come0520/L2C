module.exports=[229830,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_mobile_after-sales_route_actions_068f613c.js.map