module.exports=[793764,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_mobile_approvals_route_actions_9c022d3d.js.map