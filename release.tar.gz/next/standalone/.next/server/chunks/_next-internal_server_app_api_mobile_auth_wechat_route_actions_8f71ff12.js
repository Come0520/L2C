module.exports=[63789,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_mobile_auth_wechat_route_actions_8f71ff12.js.map