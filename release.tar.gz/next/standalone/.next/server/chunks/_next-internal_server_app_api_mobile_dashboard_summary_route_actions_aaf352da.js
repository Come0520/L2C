module.exports=[67393,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_mobile_dashboard_summary_route_actions_aaf352da.js.map