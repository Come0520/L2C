module.exports=[956286,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_mobile_leads_%5Bid%5D_claim_route_actions_cb98ed83.js.map