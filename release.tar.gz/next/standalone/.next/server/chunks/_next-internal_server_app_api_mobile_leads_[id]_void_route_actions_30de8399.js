module.exports=[325939,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_mobile_leads_%5Bid%5D_void_route_actions_30de8399.js.map