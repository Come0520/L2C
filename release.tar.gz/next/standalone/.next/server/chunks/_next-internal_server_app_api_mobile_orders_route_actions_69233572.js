module.exports=[876340,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_mobile_orders_route_actions_69233572.js.map