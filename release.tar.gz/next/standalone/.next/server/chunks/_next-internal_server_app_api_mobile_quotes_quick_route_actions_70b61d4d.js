module.exports=[72015,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_mobile_quotes_quick_route_actions_70b61d4d.js.map