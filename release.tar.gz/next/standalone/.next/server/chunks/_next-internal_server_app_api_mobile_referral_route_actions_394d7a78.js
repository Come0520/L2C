module.exports=[30379,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_mobile_referral_route_actions_394d7a78.js.map