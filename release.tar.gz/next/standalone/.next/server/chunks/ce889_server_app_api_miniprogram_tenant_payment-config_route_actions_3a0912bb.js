module.exports=[253021,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_miniprogram_tenant_payment-config_route_actions_3a0912bb.js.map