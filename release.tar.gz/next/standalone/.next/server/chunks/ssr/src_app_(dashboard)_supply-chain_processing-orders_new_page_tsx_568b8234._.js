module.exports=[436830,a=>{"use strict";var b=a.i(84063);function c(){return(0,b.jsx)("div",{className:"p-4",children:"Processing Order New Page Recovery Mode"})}a.s(["default",()=>c])}];

//# sourceMappingURL=src_app_%28dashboard%29_supply-chain_processing-orders_new_page_tsx_568b8234._.js.map