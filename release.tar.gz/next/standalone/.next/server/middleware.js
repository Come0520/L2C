var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__ba07fe5a._.js")
R.c("server/chunks/[root-of-the-server]__5a053621._.js")
R.m(895373)
module.exports=R.m(895373).exports
