'use client';

import React from 'react';

export function AddCategoryDropdown() {
    return (
        <div className="p-2 border rounded-md">
            <p className="text-muted-foreground text-sm">添加品类 (Add Category - Recovery Mode)</p>
        </div>
    );
}
