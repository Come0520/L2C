'use client';

import React from 'react';

export function AttachmentForm() {
    return (
        <div className="p-4 border rounded-md">
            <p className="text-muted-foreground">配件表单在恢复模式下暂不可用。</p>
        </div>
    );
}
