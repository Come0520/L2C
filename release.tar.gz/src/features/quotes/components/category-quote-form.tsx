'use client';

import React from 'react';

export function CategoryQuoteForm() {
    return (
        <div className="p-4 border rounded-md">
            <p className="text-muted-foreground">品类报价表单在恢复模式下暂不可用。</p>
        </div>
    );
}
