'use client';

import React from 'react';

export function CategoryTabBar() {
    return (
        <div className="flex border-b">
            <div className="p-2 border-b-2 border-primary">品类标签 (Category Tabs)</div>
        </div>
    );
}
