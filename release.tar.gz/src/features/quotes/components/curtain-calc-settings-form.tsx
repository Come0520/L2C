'use client';

import React from 'react';

export function CurtainCalcSettingsForm() {
    return (
        <div className="p-4 border rounded-md">
            <p className="text-muted-foreground">窗帘计算设置在恢复模式下暂不可用。</p>
        </div>
    );
}
