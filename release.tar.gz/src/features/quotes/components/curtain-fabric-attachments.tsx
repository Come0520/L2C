'use client';

import React from 'react';

export function CurtainFabricAttachments() {
    return (
        <div className="p-4 border rounded-md">
            <p className="text-muted-foreground">窗帘配件信息在恢复模式下暂不可用。</p>
        </div>
    );
}
