'use client';

import React from 'react';

export function CurtainFabricBasicFields() {
    return (
        <div className="p-4 border rounded-md">
            <p className="text-muted-foreground">窗帘基础字段在恢复模式下暂不可用。</p>
        </div>
    );
}
