'use client';

import React from 'react';

export function CurtainSubCategoryTabs() {
    return (
        <div className="flex gap-2">
            <div className="px-3 py-1 bg-muted rounded">子品类 (Subcategory)</div>
        </div>
    );
}
