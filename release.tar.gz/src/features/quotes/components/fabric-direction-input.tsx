'use client';

import React from 'react';

export function FabricDirectionInput() {
    return (
        <div className="p-2 border rounded-md">
            <p className="text-muted-foreground text-sm">面料方向 (Fabric Direction - Recovery Mode)</p>
        </div>
    );
}
