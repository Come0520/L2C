// AI Parser Mock
export async function parseIntent(input: string) {
    return { intent: 'unknown', data: {} };
}
