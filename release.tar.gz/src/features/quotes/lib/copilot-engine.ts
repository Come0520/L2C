'use client';

export async function parseIntent(input: string) {
    return {
        rooms: [],
        products: []
    };
}
