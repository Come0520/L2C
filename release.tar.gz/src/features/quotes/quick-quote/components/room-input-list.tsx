'use client';

import React from 'react';

export function RoomInputList() {
    return (
        <div className="space-y-4">
            <div className="py-8 text-center text-muted-foreground border-2 border-dashed rounded-lg">
                Room input list not available in recovery mode.
            </div>
        </div>
    );
}
