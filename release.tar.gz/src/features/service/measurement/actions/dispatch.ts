'use server';
export async function dispatchMeasurement(id: string, workerId: string) { return { success: true }; }
