'use client';

/**
 * 照片上传组件
 * 从共享组件重导出，保持向后兼容
 */
export { PhotoUpload, compressImage } from '@/shared/components/photo-upload';
