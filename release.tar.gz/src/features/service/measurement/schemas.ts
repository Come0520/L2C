import { z } from 'zod';

// 枚举常量
export const WINDOW_TYPES = ['STRAIGHT', 'L_SHAPE', 'U_SHAPE', 'ARC'] as const;
export const INSTALL_TYPES = ['TOP', 'SIDE'] as const;
export const WALL_MATERIALS = ['CONCRETE', 'WOOD', 'GYPSUM'] as const;
export const MEASURE_TASK_STATUS = ['PENDING_APPROVAL', 'PENDING', 'DISPATCHING', 'PENDING_VISIT', 'PENDING_CONFIRM', 'COMPLETED', 'CANCELLED'] as const;
export const MEASURE_SHEET_STATUS = ['DRAFT', 'CONFIRMED', 'ARCHIVED'] as const;
export const MEASURE_TYPES = ['QUOTE_BASED', 'BLIND', 'SALES_SELF'] as const;
export const PRODUCT_CATEGORIES = ['CURTAIN', 'WALLPAPER', 'WALLCLOTH', 'MATTRESS', 'OTHER', 'CURTAIN_FABRIC', 'CURTAIN_SHEER', 'CURTAIN_TRACK', 'MOTOR', 'CURTAIN_ACCESSORY', 'WALLCLOTH_ACCESSORY', 'WALLPANEL', 'WINDOWPAD', 'STANDARD'] as const;

// 基础明细校验
export const measureItemSchema = z.object({
    id: z.string().uuid().optional(),
    roomName: z.string().min(1, '请输入空间名称'),
    windowType: z.enum(WINDOW_TYPES),
    width: z.number().positive('宽度必须大于0').max(10000, '宽度超过限制'),
    height: z.number().positive('高度必须大于0').max(6000, '高度超过限制'),
    installType: z.enum(INSTALL_TYPES).optional(),
    bracketDist: z.number().nonnegative().optional(),
    wallMaterial: z.enum(WALL_MATERIALS).optional(),
    hasBox: z.boolean().default(false),
    boxDepth: z.number().nonnegative().optional(),
    isElectric: z.boolean().default(false),
    remark: z.string().optional(),
});

// 测量表单校验 (包含多个明细)
export const measureSheetSchema = z.object({
    taskId: z.string().uuid(),
    round: z.number().int().positive(),
    variant: z.string().min(1),
    items: z.array(measureItemSchema).min(1, '至少需要录入一个空间的测量数据'),
    sitePhotos: z.array(z.string().url()).optional(),
    sketchMap: z.string().url().optional(),
});

// 任务创建校验
export const createMeasureTaskSchema = z.object({
    leadId: z.string().uuid(),
    customerId: z.string().uuid(),
    scheduledAt: z.string().datetime().or(z.date()),
    isFeeExempt: z.boolean().default(false),
    type: z.enum(MEASURE_TYPES).default('BLIND'),
    remark: z.string().optional(),
});

// 任务指派校验
export const dispatchMeasureTaskSchema = z.object({
    id: z.string().uuid(),
    assignedWorkerId: z.string().uuid(),
    scheduledAt: z.string().datetime().or(z.date()),
});

// 签到校验
export const checkInSchema = z.object({
    id: z.string().uuid(),
    location: z.object({
        lat: z.number(),
        lng: z.number(),
        address: z.string().optional(),
        distance: z.number().optional().describe('距离客户地址的距离(米)'),
        isLate: z.boolean().optional().describe('是否迟到'),
    }),
});

// 审核/驳回校验
export const reviewMeasureTaskSchema = z.object({
    id: z.string().uuid(),
    action: z.enum(['APPROVE', 'REJECT']),
    reason: z.string().optional(),
});

// 拆单校验
export const splitMeasureTaskSchema = z.object({
    originalTaskId: z.string().uuid().describe('原始测量任务 ID'),
    splits: z.array(z.object({
        category: z.enum(PRODUCT_CATEGORIES).describe('品类'),
        workerId: z.string().uuid().optional().describe('指派的测量师 ID'),
    })).min(2, '拆单至少需要两个品类'),
    reason: z.string().optional().describe('拆单原因'),
});

// 费用豁免申请校验
export const feeWaiverSchema = z.object({
    taskId: z.string().uuid(),
    reason: z.string().min(1, '请输入豁免原因'),
});

