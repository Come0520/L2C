'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/shared/ui/card';
import { Button } from '@/shared/ui/button';
import { Switch } from '@/shared/ui/switch';
import { Input } from '@/shared/ui/input';
import { useForm } from 'react-hook-form';
import { Form, FormControl, FormField, FormItem, FormLabel, FormDescription } from '@/shared/ui/form';
import { toast } from 'sonner';
import { Loader2, Save } from 'lucide-react';
import { getSettingsByCategory, batchUpdateSettings } from '../actions/system-settings-actions';

/**
 * 测量设置组件
 * 只包含费用检查开关
 */

interface MeasureSettingsFormData {
    ENABLE_MEASURE_FEE_CHECK: boolean;
    MEASURE_LATE_THRESHOLD: number;
}

export function MeasureSettingsConfig() {
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);

    const form = useForm<MeasureSettingsFormData>({
        defaultValues: {
            ENABLE_MEASURE_FEE_CHECK: true,
            MEASURE_LATE_THRESHOLD: 30, // 默认 30 分钟
        },
    });

    useEffect(() => {
        async function loadSettings() {
            try {
                const settings = await getSettingsByCategory('MEASURE');
                if (settings && Object.keys(settings).length > 0) {
                    form.reset(settings as unknown as MeasureSettingsFormData);
                }
            } catch (error) {
                console.error('加载测量设置失败:', error);
            } finally {
                setIsLoading(false);
            }
        }
        loadSettings();
    }, [form]);

    const onSubmit = async (data: MeasureSettingsFormData) => {
        try {
            setIsSaving(true);
            // 确保数字类型正确
            const payload = {
                ...data,
                MEASURE_LATE_THRESHOLD: Number(data.MEASURE_LATE_THRESHOLD),
            };
            await batchUpdateSettings(payload as unknown as Record<string, unknown>);
            toast.success('测量设置已保存');
        } catch (error) {
            toast.error('保存失败: ' + (error instanceof Error ? error.message : '未知错误'));
        } finally {
            setIsSaving(false);
        }
    };

    if (isLoading) {
        return (
            <Card>
                <CardContent className="flex items-center justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin" />
                </CardContent>
            </Card>
        );
    }

    return (
        <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <Card>
                    <CardHeader className="pb-3">
                        <CardTitle className="text-base">测量费用准入</CardTitle>
                        <CardDescription className="text-xs">配置测量费用检查规则</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <FormField
                            control={form.control}
                            name="ENABLE_MEASURE_FEE_CHECK"
                            render={({ field }) => (
                                <FormItem className="flex items-center justify-between rounded-lg border p-3">
                                    <div className="space-y-0.5">
                                        <FormLabel>启用费用检查</FormLabel>
                                        <FormDescription className="text-xs">
                                            开启后需满足以下条件之一才能发起测量：已支付定金 或 已通过免费测量审批
                                        </FormDescription>
                                    </div>
                                    <FormControl>
                                        <Switch checked={field.value} onCheckedChange={field.onChange} />
                                    </FormControl>
                                </FormItem>
                            )}
                        />

                        <FormField
                            control={form.control}
                            name="MEASURE_LATE_THRESHOLD"
                            render={({ field }) => (
                                <FormItem className="flex items-center justify-between rounded-lg border p-3">
                                    <div className="space-y-0.5">
                                        <FormLabel>迟到判定阈值 (分钟)</FormLabel>
                                        <FormDescription className="text-xs">
                                            签到时间超过预约时间多少分钟判定为迟到
                                        </FormDescription>
                                    </div>
                                    <FormControl>
                                        <Input
                                            type="number"
                                            className="w-24 text-right"
                                            {...field}
                                            onChange={(e) => field.onChange(Number(e.target.value))}
                                        />
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                    </CardContent>
                </Card>

                <div className="flex justify-end">
                    <Button type="submit" disabled={isSaving}>
                        {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                        保存设置
                    </Button>
                </div>
            </form>
        </Form>
    );
}
