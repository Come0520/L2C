import { describe, it, expect } from 'vitest';
describe('Suppliers Tests', () => {
    it('should pass', () => {
        expect(true).toBe(true);
    });
});
