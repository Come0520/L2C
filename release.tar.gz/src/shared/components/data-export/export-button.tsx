import React from 'react';
import { Button } from '@/shared/ui/button';
export function ExportButton() { return <Button>导出 (Export)</Button>; }
