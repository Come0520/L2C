export const checkPermission = (_role: string, _permission: string) => true;
