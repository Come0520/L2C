export const rolePermissionService = {
    hasPermission: () => true,
};
