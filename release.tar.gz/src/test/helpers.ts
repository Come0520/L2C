export function mockDb() {
    return {};
}
