'use client';
import React from 'react';
export function Breadcrumb() { return <div className="p-2">Breadcrumb Mock</div>; }
